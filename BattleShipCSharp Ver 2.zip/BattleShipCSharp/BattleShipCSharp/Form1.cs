﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BattleShipCSharp
{
    public partial class Form1 : Form
    {
        static Random Rnd = new Random();
        //int index;
        PictureBox[] PlayerGrid = new PictureBox[100];
        PictureBox[] ComputerGrid = new PictureBox[100];
        char[] PlayerGameGrid = new char[100];
        char[] ComputerGameGrid = new char[100];
        Boolean WasHit;
        int NextRand;
        int[] RandomSourceForHit;
        //PictureBox PictBox = new PictureBox();
        //Image[] Pictures = new Image[6];
        //char[] GameGrid = new char[256];
        //int count;
        //Boolean letclick;
        //Boolean setbox;
        //Boolean setwall;
        //Boolean setblank;
        //Boolean setchar;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int PlayerX, PlayerY, ComputerX, ComputerY;
            PlayerX = 10;
            PlayerY = 100;
            ComputerX = 610;
            ComputerY = 100;
            WasHit = false;
            InitGrid(PlayerX, PlayerY, "Player");
            InitGrid(ComputerX, ComputerY, "Computer");
            PlaceShips("Player");
            PlaceShips("Computer");
            Rich1Show();
            Rich2Show();

        }
        private void Rich1Show()
        {
            richTextBox1.Text = "";
            for (int i = 0; i < 99; i++)
            {
                richTextBox1.Text = richTextBox1.Text + PlayerGameGrid[i] + ",";
                if ((i + 1) % 10 == 0)
                {
                    richTextBox1.Text = richTextBox1.Text + "\n";
                }
            }
        }
        private void Rich2Show()
        {
            richTextBox2.Text = "";
            for (int i = 0; i < 99; i++)
            {
                richTextBox2.Text = richTextBox2.Text + ComputerGameGrid[i] + ",";
                if ((i + 1) % 10 == 0)
                {
                    richTextBox2.Text = richTextBox2.Text + "\n";
                }
            }
        }
        private void InitGrid(int x, int y, String Who)
        {

            for (int i = 0; i < 100; i++)
            {
                if (Who == "Player")
                {
                    PlayerGrid[i] = new PictureBox();
                    PlayerGrid[i].Name = "PlayerPictureBox"+ (i + 1).ToString();
                    PlayerGameGrid[i] = 'W';
                    PlayerGrid[i].ImageLocation = "water.jpg";
                    // set position and size
                    PlayerGrid[i].Location = new Point(x, y);
                }
                else
                {
                    ComputerGrid[i] = new PictureBox();
                    ComputerGrid[i].Name = "ComputerPictureBox" + (i + 1).ToString();
                    ComputerGameGrid[i] = 'W';
                    ComputerGrid[i].ImageLocation = "water.jpg";
                    // set position and size
                    ComputerGrid[i].Location = new Point(x, y);
                }
                if ((i + 1) % 10 == 0)
                {
                    if (Who == "Player")
                    {
                        x = 10;
                    }
                    else
                    {
                        x = 610;
                    }
                    y = y + 50;
                }
                else
                {
                    x = x + 50;
                }
                if (Who == "Player")
                {
                    PlayerGrid[i].Size = new Size(50, 50);
                    this.Controls.Add(PlayerGrid[i]);

                    PlayerGrid[i].Click += new EventHandler(OnPlayerPicClick);
                }
                else
                {
                    ComputerGrid[i].Size = new Size(50, 50);
                    this.Controls.Add(ComputerGrid[i]);

                    ComputerGrid[i].Click += new EventHandler(OnComputerPicClick);
                }
            }
        }
        private void OnPlayerPicClick(object sender, EventArgs e)
        {
            //var Which = (PictureBox)sender;
           // Which.ImageLocation = "Explosion.jpg";
        }
        private void OnComputerPicClick(object sender, EventArgs e)
        {
            var Which = (PictureBox)sender;
            String ControlName;
            ControlName = Which.Name;
            int Index;
            int Len;
            Len = ControlName.Length;
            Index = Convert.ToInt32(ControlName.Substring(18, Len -18));
            Index--;
            if (ComputerGameGrid[Index] == 'W')
            {
                Which.ImageLocation = "Miss.jpg";
                ComputerGameGrid[Index] = 'M'; 
            }
            if (ComputerGameGrid[Index] == 'S')
            {
                Which.ImageLocation = "Hit.jpg";
                ComputerGameGrid[Index] = 'H';
            }
            if (CheckWinner("Player") == true)
            {
                MessageBox.Show("Computer Won!!!");
                Application.Exit(); 
            }
            //Rich1Show();
            //Rich2Show();
           // Check for Winner 

           // Ai for Computer 
            
            while (true)
            {
                if (WasHit == true)
                {

                    while (true)
                    {
                        Index = RandomSourceForHit[Rnd.Next(0, RandomSourceForHit.Length - 1)];
                        if (PlayerGameGrid[Index] == 'S')
                        {
                            break;
                        }
                        else
                        {
                            //PlayerGameGrid[Index] = 'M';
                        }
                    }
                   
                }
                else
                {
                    Index = Rnd.Next(0, 99);
                }
                if (PlayerGameGrid[Index] == 'W')
                {
                    PlayerGameGrid[Index] = 'M';
                    PlayerGrid[Index].ImageLocation = "Miss.jpg";
                    WasHit = false;
                    break;
                }
                if (PlayerGameGrid[Index] == 'S')
                {
                    PlayerGameGrid[Index] = 'H';
                    PlayerGrid[Index].ImageLocation = "Hit.jpg";
                    //add some Ai for next 
                    RandomSourceForHit = FindNeighbours(Index);
                    // Make sure the second hit wipes off Hit Switch             
                    if (WasHit == false)
                    {
                        WasHit = true;
                    }
                    else
                    {
                        WasHit = false; 
                    }
                    if (CheckWinner("Computer") == true)
                    {
                        MessageBox.Show("You Won!!!");
                        Application.Exit();
                    }
                    //for (int j = 0; j < RandomSourceForHit.Length; j++)
                    //{
                    //    richTextBox3.Text = richTextBox3.Text + RandomSourceForHit[j] + ", ";
                    //}
                    break;                
                }

            }
        }
        private void PlaceShips(String Who )
        {
            int[] RandomSource = {11, 12, 13, 14, 15, 16, 17, 18,
                                  21, 22, 23, 24, 25, 26, 27, 28,
                                  31, 32, 33, 34, 35, 36, 37, 38, 
                                  41, 42, 43, 44, 45, 46, 47, 48, 
                                  51, 52, 53, 54, 55, 56, 57, 58,
                                  61, 62, 63, 64, 65, 66, 67, 68,
                                  71, 72, 73, 74, 75, 76, 77, 78, 
                                  81, 82, 83, 84, 85, 86, 87, 88};
            
            int Index;
            String ControlName; 
            for (int NoofShips = 1; NoofShips <= 3; NoofShips++)
            {
                // Check for collision
                while (true)
                {
                    Index = RandomSource[Rnd.Next(0, RandomSource.Length - 1)];
                    textBox1.Text = textBox1.Text + Index + ";";
                    if (Who == "Player")
                    {
                        if (PlayerGameGrid[Index] == 'W' &&
                            PlayerGameGrid[Index - 1] == 'W' &&
                            PlayerGameGrid[Index + 10] == 'W')
                            break;
                    }
                    else
                    {
                        if (ComputerGameGrid[Index] == 'W' &&
                            ComputerGameGrid[Index - 1] == 'W' &&
                            ComputerGameGrid[Index + 10] == 'W')
                            break;
                         
                    }
                }
                if (Index % 2 == 0)
                {
                    // Placement Horizental
                    if (Who == "Player")
                    {
                        PlayerGameGrid[Index - 1] = 'S';
                        PlayerGameGrid[Index] = 'S';

                                PlayerGrid[Index -1 ].ImageLocation = "BattleH1.jpg";
                                PlayerGrid[Index].ImageLocation = "BattleH2.jpg";    
                     
                    }
                    else
                    {
                        ComputerGameGrid[Index - 1] = 'S';
                        ComputerGameGrid[Index] = 'S';
                    }
                }
                else
                {
                    // Placement vertical 
                    if (Who == "Player")
                    {
                        PlayerGameGrid[Index] = 'S';
                        PlayerGameGrid[Index + 10] = 'S';
                        ControlName = "PlayerPictureBox" + Index.ToString();

                                PlayerGrid[Index].ImageLocation = "BattleV1.jpg";
                                PlayerGrid[Index + 10].ImageLocation = "BattleV2.jpg";

                    }
                    else
                    {
                        ComputerGameGrid[Index] = 'S';
                        ComputerGameGrid[Index + 10] = 'S';
                    }
                }
            }   
        }
        private int [] FindNeighbours(int Cell)
        {
            if (Cell == 0)
            {
                int[] RandSrc = { 1, 10, 11 };
                return RandSrc;
            }
            if (Cell >= 1 && Cell <= 8)
            {
                int[] RandSrc = { Cell - 1,Cell + 1, Cell+ 9, Cell + 10, Cell + 11 };
                return RandSrc;
            }
            if (Cell == 9)
            {
                int[] RandSrc = { 8, 18, 19};
                return RandSrc;
            }
            if (Cell == 90)
            {
                int[] RandSrc = { 80, 81, 91 };
                return RandSrc;
            }
            if (Cell >= 91 && Cell <= 98)
            {
                int[] RandSrc = { Cell - 11, Cell - 10, Cell - 9, Cell - 1, Cell + 1 };
                return RandSrc;
            }
          
            if (Cell == 99)
            {
                int[] RandSrc = { 89, 88, 98 };
                return RandSrc;
            }
            if (Cell == 10 || Cell == 20 ||Cell == 30 ||
                Cell == 40 || Cell == 50 ||Cell == 60 ||
                Cell == 70 || Cell == 80 )
                
            {
                 int[] RandSrc = {Cell -10 ,Cell - 9, Cell + 1, Cell + 10, Cell + 11};
                 return RandSrc;
            }
            if (Cell == 19 || Cell == 29 || Cell == 39 ||
                Cell == 49 || Cell == 59 || Cell == 69 ||
                Cell == 79 || Cell == 89)
            {
                int[] RandSrc = { Cell - 10, Cell - 11, Cell -1, 1, Cell + 9, Cell + 10 };
                return RandSrc;
            }

            int[] RandSrc1 = {Cell -11  , Cell -10, Cell - 9, Cell - 1, Cell + 1, Cell + 9 , Cell + 10, Cell + 11 };
            return RandSrc1;   
            
        }
        private Boolean CheckWinner(String Who)
        {
            int HitCount;
            
            if (Who == "Player")
            {
                HitCount = 0;
                for (int i = 0; i <= 99; i++)
                {
                    if (PlayerGameGrid[i] == 'H')
                    {
                        HitCount++;
                    }
                }
                if (HitCount == 6)
                {
                    return true;
                }
                else
                {
                    return false;
                }
               
            }
            else
            {
                HitCount = 0;
                for (int i = 0; i <= 99; i++)
                {
                    if (ComputerGameGrid[i] == 'H')
                    {
                        HitCount++;
                    }
                }
                if (HitCount == 6)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }
    }
    
}
