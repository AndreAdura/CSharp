﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsharpAccessBooks
{
    public partial class Form1 : Form
    {
        ADODB.Connection Con;
        ADODB.Recordset Rs;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Con = new ADODB.Connection();
            Rs = new ADODB.Recordset();
            Con.Provider = "Microsoft.jet.oledb.4.0";
            Con.ConnectionString = "c:\\database\\CsharpBooks.mdb";
            Con.Open();
            Rs.Open("Select * from Bookstable", Con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Rs.EOF == true && Rs.BOF == true)
            {
                MessageBox.Show("Table is Empty!");
                return;
            }
            Rs.MoveFirst();
            ShowDataOnForm();
        }
        public void ShowDataOnForm()
        {
            textBox1.Text = Convert.ToString( Rs.Fields["ISBN"].Value);
            textBox2.Text = Convert.ToString( Rs.Fields["Title"].Value);
            textBox3.Text = Convert.ToString( Rs.Fields["Author"].Value);
            textBox4.Text = Convert.ToString( Rs.Fields["Category"].Value);
            textBox5.Text = Convert.ToString( Rs.Fields["Ebook"].Value);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClearBoxes();
        }
        public void ClearBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Rs.EOF == true && Rs.BOF == true)
            {
                MessageBox.Show("Table is Empty!");
                return;
            }
            Rs.MoveLast();
            ShowDataOnForm();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Rs.EOF == true && Rs.BOF == true)
            {
                MessageBox.Show("Table is Empty!");
                return;
            }
            Rs.MoveNext();
            if(Rs.EOF == true )
            {
                Rs.MoveLast(); 
                MessageBox.Show("Passed End of File");
            }
            ShowDataOnForm(); 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Rs.EOF == true && Rs.BOF == true)
            {
                MessageBox.Show("Table is Empty!");
                return;
            }
            Rs.MovePrevious();
            if(Rs.BOF == true )
            {
                Rs.MoveFirst(); 
                MessageBox.Show("Passed Beginning of File");
            }
            ShowDataOnForm(); 
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please Enter an ISBN to find");
                return;
            }
            String Criteria;
            Criteria = "ISBN =" + textBox1.Text;
            Rs.MoveFirst();
            //go to the beginning to start serach 
            Rs.Find(Criteria);
            // Either We find the record(s), which is the first record if there are more than one
            // If record is found the file pointer stays at it
            //if not found, the file pointer has passed eof meaning eof = true
            if (Rs.EOF == true)
            {
                //not found
                MessageBox.Show("Record with this ISBN does not exist");
                return;
            }
            else
            {
                //found 
                ShowDataOnForm();
                MessageBox.Show("Record found succesfully");
            }
  
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                MessageBox.Show("Please Enter an Author to find");
                return;
            }
            String Criteria;
            Criteria = "Author ='" + textBox3.Text + "'";
            Rs.MoveFirst();
            //go to the beginning to start serach 
            Rs.Find(Criteria);
            // Either We find the record(s), which is the first record if there are more than one
            // If record is found the file pointer stays at it
            //if not found, the file pointer has passed eof meaning eof = true
            if (Rs.EOF == true)
            {
                //not found
                MessageBox.Show("Record with this Author does not exist");
                return;
            }
            else
            {
                //found 
                ShowDataOnForm();
                MessageBox.Show("Record found succesfully");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            String Criteria;
            Criteria = "";
            if (textBox1.Text != "")
            {
                Criteria = Criteria + "ISBN = " + textBox1.Text;
            }
            if (textBox2.Text != "")
            {
                if (Criteria != "")
                {
                    Criteria = Criteria + " AND Title = '" + textBox2.Text + "'";
                }
                else
                {
                    Criteria = Criteria + "Title = '" + textBox2.Text + "'";
                }
            }
            if (textBox3.Text != "")
            {
                if (Criteria != "")
                {
                    Criteria = Criteria + " AND Author = '" + textBox3.Text + "'";
                }
                else
                {
                    Criteria = Criteria + "Author = '" + textBox3.Text + "'";
                }
            }
            if (textBox4.Text != "")
            {
                if (Criteria != "")
                {
                    Criteria = Criteria + " AND Category = '" + textBox4.Text + "'";
                }
                else
                {
                    Criteria = Criteria + "Category = '" + textBox4.Text + "'";
                }
            }
            if (textBox5.Text != "")
            {
                if (Criteria != "")
                {
                    Criteria = Criteria + " AND ebook = '" + textBox5.Text + "'";
                }
                else
                {
                    Criteria = Criteria + "ebook = '" + textBox5.Text + "'";
                }
            }
           
            Rs.MoveFirst();
            Rs.Filter = Criteria;
            if (Rs.EOF == true)
            {
                //not found
                MessageBox.Show("Recod with your specific criteria not found");
                return;
            }
            else
            {
                ShowDataOnForm();
                Rs.Filter = "";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
                textBox2.Text == "" ||
                textBox3.Text == "" ||
                textBox4.Text == "" ||
                textBox5.Text == "")
            {
                MessageBox.Show("Please Fill up all boxes");
                return;
            }
            String Criteria;
            Criteria = "ISBN =" + textBox1.Text;
            Rs.MoveFirst();
            //go to the beginning to start serach 
            Rs.Find(Criteria);
            //Either We find the record(s), which is the first record if there are more than one
            //If record is found the file pointer stays at it
            //if not found, the file pointer has passed eof meaning eof = true
            if (Rs.EOF == true)
            {
                //not found
                Rs.AddNew();
                SaveinTable();
                Rs.Update();
                MessageBox.Show("Record Added succesfully");
                ClearBoxes();
                return;
            }
            else
            {
                //found 
                MessageBox.Show("Duplicate Record, try another ISBN");
                return;
            }
        }
        private void SaveinTable()
        {
            Rs.Fields["ISBN"].Value = textBox1.Text;
            Rs.Fields["Title"].Value = textBox2.Text;
            Rs.Fields["Author"].Value = textBox3.Text;
            Rs.Fields["Category"].Value = textBox4.Text;
            Rs.Fields["ebook"].Value = textBox5.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
                textBox2.Text == "" ||
                textBox3.Text == "" ||
                textBox4.Text == "" ||
                textBox5.Text == "")
            {
                MessageBox.Show("Please Fill up all boxes");
                return;
            }
            String Criteria;
            Criteria = "ISBN =" + textBox1.Text;
            Rs.MoveFirst();
            //go to the beginning to start serach 
            Rs.Find(Criteria);
            //Either We find the record(s), which is the first record if there are more than one
            // If record is found the file pointer stays at it
            //if not found, the file pointer has passed eof meaning eof = true
            if (Rs.EOF)
            {
                // it is impossible, if you refrain from changing the ID 
                MessageBox.Show("Record with this ISBN does not exist");
                return;
            }
            else
            {
                //found 
                SaveinTable();
                Rs.Update();
                MessageBox.Show("Record Modified succesfully");
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" ||
                textBox2.Text == "" ||
                textBox3.Text == "" ||
                textBox4.Text == "" ||
                textBox5.Text == "")
            {
                MessageBox.Show("Please Fill up all boxes");
                return;
            }
            String Criteria;
            Criteria = "ISBN =" + textBox1.Text;
            Rs.MoveFirst();
            //go to the beginning to start serach 
            Rs.Find(Criteria);
            //Either We find the record(s), which is the first record if there are more than one
            // If record is found the file pointer stays at it
            //if not found, the file pointer has passed eof meaning eof = true
            if (Rs.EOF)
            {
                // it is impossible, if you refrain from changing the ID 
                MessageBox.Show("Record with this ISBN does not exist");
                return;
            }
            else
            {
                //found 
                //confirm 
                DialogResult  MsgbxResult;
                MsgbxResult = MessageBox.Show("Are you Sure?!", "Confirm Delete", MessageBoxButtons.YesNo );
                if (Convert.ToString(MsgbxResult) == "Yes")
                {
                    Rs.Delete();
                    Rs.Update();
                    MessageBox.Show("Record Deleted Successfully !!!");
                    ClearBoxes();

                }

            }
        }
    } 
}
